#include <stdio.h>
int main() {
  int a = 10;
  int b = 100;
  int c = a * b;
  printf("%d * %d = %d\n", a, b, c);
  return 0;
}
